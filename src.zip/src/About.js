import React from "react";

class About extends React.Component{
    constructor(){
        super()
        this.state={
            about:'About Me'
        }

    }
    componentDidMount(){
        console.log('app mount')
    }
    componentDidUpdate(){
        console.log('when update occure')
    }

    render(){
        return(
            <>
             <div className="container">
        <div className="row">
          <div className="col-md-4">
            <h2>{this.state.about}</h2>
          </div>
          <div className="col-md-8">
            <p >
              Seeking a career to gain relevant experience and apply my
              educational background and personal skills. I expect to be a
              team player, professional, reliable, and play an active role
              wherever I'm.
            </p>
          </div>
        </div>
      </div>
            </>
        
        )
    }
}

export default About;
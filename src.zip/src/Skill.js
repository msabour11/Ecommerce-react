import React from "react";

class Skill extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <>
        <div className="container">
          <div className="row">
            <div className="skillhead col-md-12 col-lg-12">
              <h3>Skills</h3>
            </div>
            <div className="parg col-lg-12">
            <p>
            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, enim quaerat? Velit laudantium asperiores odit modi fugiat molestias, facere animi magnam maiores sed labore adipisci in atque, dolor voluptatibus minus?
    
    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, enim quaerat? Velit laudantium asperiores odit modi fugiat molestias, facere animi magnam maiores sed labore adipisci in atque, dolor voluptatibus minus?
    
            </p>
            </div>
            <div className="col-lg-12" style={{marginTop:'30px'}}>
        <div className="progress custom-progress-bar">
          <div className="progress-bar" role="progressbar" style={{ width: "80%" }} aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">HTML/CSS</div>
        </div>
        <div className="progress custom-progress-bar">
          <div className=" progress-bar" role="progressbar" style={{ width: "70%" }} aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">JavaScript</div>
        </div>
        <div className="progress custom-progress-bar">
          <div className=" progress-bar" role="progressbar" style={{ width: "60%" }} aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">BootStrap</div>
        </div>
        <div className="progress custom-progress-bar">
          <div className=" progress-bar" role="progressbar" style={{ width: "86%" }} aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">RedHat</div>
        </div>
        <div className="progress custom-progress-bar">
          <div className=" progress-bar" role="progressbar" style={{ width: "80%" }} aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">MYSql</div>
        </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default Skill;



// import React from "react";

// class Skill extends React.Component {
//   constructor(props) {
//     super(props);
//   }

//   render() {
//     return (
//       <div className="container">
//         <div className="row">
//           <div className="col-md-12">
//             <div className="skill-heading text-center">
//               <h2>Skills</h2>
//             </div>
//           </div>
//         </div>
//         <div className="row">
//           <div className="col-md-6">
//             <div className="skill-description">
//               <p>
//                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, enim quaerat? Velit laudantium asperiores odit modi fugiat molestias, facere animi magnam maiores sed labore adipisci in atque, dolor voluptatibus minus?
//               </p>
//               <p>
//                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Et, enim quaerat? Velit laudantium asperiores odit modi fugiat molestias, facere animi magnam maiores sed labore adipisci in atque, dolor voluptatibus minus?
//               </p>
//             </div>
//           </div>
//           <div className="col-md-6">
//             <div className="skill-progress">
//               <div className="progress">
//                 <div className="progress-bar bg-primary" role="progressbar" style={{ width: "80%" }} aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">
//                   HTML/CSS
//                 </div>
//               </div>
//               <div className="progress">
//                 <div className="progress-bar bg-success" role="progressbar" style={{ width: "70%" }} aria-valuenow="70" aria-valuemin="0" aria-valuemax="100">
//                   JavaScript
//                 </div>
//               </div>
//               {/* Add more skills and progress bars here */}
//             </div>
//           </div>
//         </div>
//       </div>
//     );
//   }
// }

// export default Skill;


import About from './About';
import './App.css';
import Card from './Card';
import Footer from './Footer';
import Skill from './Skill';
// import Button from './Button';
import Hero from './hero';

function App() {
  return (
    <>
    <Hero/>
    <About/>
    {/* <Button/> */}
    <Skill/>
    <Card></Card>
    <Footer/>
    </>
  );
}

export default App;

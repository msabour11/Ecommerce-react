import React from "react";
import backgroundImage from "../src/hero.jpg"
import './App.css';
import Button from "./Button";

class Hero extends React.Component{

    constructor(props){
        super()
    }

     heroStyle = {
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        height:'300px'
   

      };
    render(){
return  (
    <section className="hero" style={this.heroStyle}>
    <div className="container">
      <div className="row">
        <div className="col-md-6">
          <h1 className="display-4">Mohamed Sabour</h1>
          <p className="lead">
            I am a passionate web developer ready to create amazing projects.
          </p>
          <Button/>
        </div>
        <div className="col-md-6">
          {/* You can add an image or any other content here */}
        </div>
      </div>
    </div>
  </section>
 

);

    }
    
}
export default Hero
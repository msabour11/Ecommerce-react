import React from "react";
import Button from "./Button";

class Footer extends React.Component {
  render() {
    return (
      <footer className="bg-dark text-light">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              {/* <h3>Contact Us</h3> */}
              <Button className='btnfooter'/>
              <p>Email: example@example.com</p>
              <p>Phone: +1 (123) 456-7890</p>
            </div>
            <div className="col-md-6 links">
              <h3>Follow Us</h3>
              <ul className="list-unstyled list-inline">
                <li className="list-inline-item">
                  <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
                    <i className="fab fa-facebook"></i> Facebook
                  </a>
                </li>
                <li className="list-inline-item">
                  <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer">
                    <i className="fab fa-twitter"></i> Twitter
                  </a>
                </li>
                <li className="list-inline-item">
                  <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
                    <i className="fab fa-linkedin"></i> LinkedIn
                  </a>
                </li>
                <li className="list-inline-item">
                  <a href="https://www.github.com" target="_blank" rel="noopener noreferrer">
                    <i className="fab fa-github"></i> GitHub
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    );
  }
}

export default Footer;
